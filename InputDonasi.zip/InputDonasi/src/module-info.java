module inputDonasi {
	requires java.desktop;
}